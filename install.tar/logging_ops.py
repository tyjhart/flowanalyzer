# Copyright 2016, Manito Networks, LLC. All rights reserved
#
# Last modified 6/10/2016

import time, datetime
def log_time():
    return str(datetime.datetime.utcnow()) + " "